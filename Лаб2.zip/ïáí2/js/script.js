function addColor1(){
  $("#repass").css("border", "1px solid blue");
}
function addColor2(){
  $("#login").css("border", "1px solid green");
}
function addColor3(){
  $("#pass").css("border", "1px solid red");
}